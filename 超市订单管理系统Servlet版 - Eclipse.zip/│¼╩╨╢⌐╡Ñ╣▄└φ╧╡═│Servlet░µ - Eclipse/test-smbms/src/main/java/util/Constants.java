package util;

public class Constants {
	public static final String USER_SESSION = "userSession";
	public final static String SYS_MESSAGE = "message";
	public final static int pageSize = 5;
}
