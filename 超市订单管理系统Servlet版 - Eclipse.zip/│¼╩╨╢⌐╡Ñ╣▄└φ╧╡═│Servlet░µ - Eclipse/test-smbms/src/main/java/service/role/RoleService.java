package service.role;

import java.util.List;

import pojo.Role;

public interface RoleService {
	//角色列表查询
	public List<Role> getRoleList();  
	
}
